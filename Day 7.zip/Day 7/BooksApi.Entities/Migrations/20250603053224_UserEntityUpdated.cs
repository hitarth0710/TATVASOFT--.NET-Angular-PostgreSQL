﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BooksApi.Entities.Migrations
{
    /// <inheritdoc />
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    [Migration("20250603053224_UserEntityUpdated")]
    [DbContext(typeof(BookDbContext))]
    [Designer("Hitarth_Laptop")]
    public partial class UserEntityUpdated : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
